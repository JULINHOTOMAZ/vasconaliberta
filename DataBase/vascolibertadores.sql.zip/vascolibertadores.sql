-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 03-Jan-2018 às 18:29
-- Versão do servidor: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vascolibertadores`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `postnews`
--

CREATE TABLE `postnews` (
  `Titulo` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `SubTitulo` varchar(240) COLLATE utf8_unicode_ci NOT NULL,
  `Imagem` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `DataPostagem` datetime NOT NULL,
  `COD` mediumint(8) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Extraindo dados da tabela `postnews`
--

INSERT INTO `postnews` (`Titulo`, `SubTitulo`, `Imagem`, `DataPostagem`, `COD`) VALUES
('No jogo da volta em São Januário novamente a equipe foi superior, não deu chances.', 'Luis Fabiano cumpriu com o prometido e voltou com força máxima anotando 2 gols na vitória de virada por 3 x 1.', 'img/foot3.jpg', '2017-12-25 00:00:00', 1),
('Diante dos chilenos o vasco foi superior, iniciou sua trajetória com um elástico 3 x 0.', 'Martin Silva teve atuação brilhante, e ajudou o time a sair com a vantagem no primeiro confronto da competição.', 'img/foot.jpg', '2017-12-27 00:00:00', 2),
('O próximo desáfio do vasco sairá do vecedor da partida entre Jorge Wilsterman x Oriente Petrolero.', 'A preparação do tima começará já nesta Segunda visando o confronto que será disputado no dia 14 de fevereiro.', 'img/foot2.jpg', '2017-12-30 00:00:00', 3),
('Novidade em São Januáro, o estádio sofrerá uma reforma para mudar os bancos de reservas.', 'Antes da fase de grupos o vasco irá mudar os bancos de reservas atrás dos gols para próximos às cabines de transmissão.', 'img/foot4.jpg', '2017-12-31 19:36:36', 4),
('Há 90 anos, Vasco promovia festa de Natal para as crianças pobres em SJ', 'Resultou verdadeiro acontecimento o primeiro Natal das crianças pobres promovido pelo C. R. Vasco da Gama, no estádio de S. Januario.', 'img/foot4.jpg', '2017-12-26 04:17:10', 6);

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `UserName` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `PassWord` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `Email` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `Cod` mediumint(8) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `postnews`
--
ALTER TABLE `postnews`
  ADD PRIMARY KEY (`COD`);

--
-- Indexes for table `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`Email`),
  ADD UNIQUE KEY `Cod` (`Cod`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `postnews`
--
ALTER TABLE `postnews`
  MODIFY `COD` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `usuario`
--
ALTER TABLE `usuario`
  MODIFY `Cod` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
